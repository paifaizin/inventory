 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Kategorie CRUD</h2>
            </div>
            <div class="pull-right">

                    <a class="btn btn-success" href="<?php echo e(route('kategorie.create')); ?>"> Create New Kategorie</a>

                
            </div>
        </div>
        <div class="col-lg-12">
            
                <?php echo Form::open(array('route' => 'kategorie.index','method'=>'GET')); ?>

                <div class="col-md-4">
                    <?php echo Form::text('title', null, array('placeholder' => 'Search by Title','class' => 'form-control')); ?>

                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <?php echo Form::close(); ?>

            
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Title</th>
            <th>Status</th>
            <th width="280px">Action</th>
        </tr>
    <?php $__currentLoopData = $kategorie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($item->title); ?></td>
        <td><?php echo e($item->status == "1" ? "Aktif" : "Nonaktif"); ?></td>
        <td>
            <a class="btn btn-info" href="<?php echo e(route('kategorie.show',$item->id)); ?>">Show</a>
            <a class="btn btn-primary" href="<?php echo e(route('kategorie.edit',$item->id)); ?>">Edit</a>
            <?php echo Form::open(['method' => 'DELETE','route' => ['kategorie.destroy', $item->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?>

        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $kategorie->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
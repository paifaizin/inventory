<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Kategorie extends Model
{

    public $fillable = ['title','status'];

}
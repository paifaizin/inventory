@extends('layouts.default')
 
@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Location CRUD</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('location.create') }}"> Create New Location</a>
            </div>
        </div>

        <div class="col-lg-12">
            
                {!! Form::open(array('route' => 'location.index','method'=>'GET')) !!}
                <div class="col-md-4">
                    {!! Form::text('title', null, array('placeholder' => 'Search by Title','class' => 'form-control')) !!}
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                {!! Form::close() !!}
            
        </div>

    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Title</th>
            <th>Address</th>
            <th>Status</th>
            <th width="280px">Action</th>
        </tr>
    @foreach ($location as $key => $item)
    <tr>
        <td>{{ ++$i }}</td>
        <td>{{ $item->title }}</td>
        <td>{{ $item->address }}</td>
        <td>{{ $item->status == "1" ? "Aktif" : "Nonaktif" }}</td>
        <td>
            <a class="btn btn-info" href="{{ route('location.show',$item->id) }}">Show</a>
            <a class="btn btn-primary" href="{{ route('location.edit',$item->id) }}">Edit</a>
            {!! Form::open(['method' => 'DELETE','route' => ['location.destroy', $item->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
            {!! Form::close() !!}
        </td>
    </tr>
    @endforeach
    </table>

    {!! $location->render() !!}

@endsection
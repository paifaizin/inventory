@extends('layouts.default')
 
@section('content')
    <div class="row">
        <div class="col-md-12">
            
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Kategorie CRUD</h2>
            </div>
            <div class="pull-right">

                    <a class="btn btn-success" href="{{ route('kategorie.create') }}"> Create New Kategorie</a>

                
            </div>
        </div>
        <div class="col-lg-12">
            
                {!! Form::open(array('route' => 'kategorie.index','method'=>'GET')) !!}
                <div class="col-md-4">
                    {!! Form::text('title', null, array('placeholder' => 'Search by Title','class' => 'form-control')) !!}
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                {!! Form::close() !!}
            
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Title</th>
            <th>Status</th>
            <th width="280px">Action</th>
        </tr>
    @foreach ($kategorie as $key => $item)
    <tr>
        <td>{{ ++$i }}</td>
        <td>{{ $item->title }}</td>
        <td>{{ $item->status == "1" ? "Aktif" : "Nonaktif" }}</td>
        <td>
            <a class="btn btn-info" href="{{ route('kategorie.show',$item->id) }}">Show</a>
            <a class="btn btn-primary" href="{{ route('kategorie.edit',$item->id) }}">Edit</a>
            {!! Form::open(['method' => 'DELETE','route' => ['kategorie.destroy', $item->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
            {!! Form::close() !!}
        </td>
    </tr>
    @endforeach
    </table>

    {!! $kategorie->render() !!}

@endsection